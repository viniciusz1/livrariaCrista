package vinicius;

import java.util.Scanner;

public class ex6 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		double salario, salario1;
		int a;

		System.out.println("Digite seu sal�rio: ");
		salario = sc.nextDouble();

		if (salario <= 1200) {
			salario = salario + salario * 0.13;
		} else if (salario > 1200 && salario <= 1600) {
			salario = salario + salario * 0.11;
		} else if (salario > 1600 && salario <= 2000) {
			salario = salario + salario * 0.13;
		} else {
			salario = salario + salario * 0.07;
		}

		if (salario < 1500) {
			a = 1;
		} else {
			a = 2;
		}

		switch (a) {
		case 1:
			salario1 = salario + 300;
			System.out.println("Seu sal�rio � de: " + salario1 + "\nSeu vale tem o valor de 300");
			break;
		case 2:
			System.out.println("Seu sal�rio � de:" + salario);
			break;
		}

		sc.close();
	}
}
