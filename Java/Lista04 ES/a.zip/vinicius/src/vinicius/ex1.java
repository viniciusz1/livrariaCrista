package vinicius;

import java.util.Scanner;

public class ex1 {
public static void main(String[] args) {
Scanner sc = new Scanner(System.in);

int numero;

System.out.println("Digite um n�mero: ");
numero = sc.nextInt();
numero = numero%5;


switch(numero) {
case 0:
System.out.println("Seu n�mero � divis�vel por 5");
break;
default:
	System.out.println("Se n�mero n�o � divis�vel por 5");
}

sc.close();
}
}
