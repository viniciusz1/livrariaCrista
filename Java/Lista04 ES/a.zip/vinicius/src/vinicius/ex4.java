package vinicius;

import java.util.Scanner;

public class ex4 {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	
	int num1, num2, resultado = 0;
	char operador;
	
	System.out.println("Digite dois n�meros");
	num1 = sc.nextInt();
	num2 = sc.nextInt();
	
	System.out.println("Digite o operador aritm�tico que voc� deseja realizar na sua conta"
			+ "\n* = multiplica��o"
			+ "\n/ = divis�o"
			+ "\n- = subtra��o"
			+ "\n+ = adi��o");
	operador = sc.next().charAt(0);
	
	switch(operador) {
	case '+':
		resultado = num1 + num2;
		break;
	case'*':
		resultado = num1 * num2;
		break;
	case'-':
		resultado = num1 - num2;
		break;
	case'/':
		resultado = num1 / num2;
		break;
	}
	
	System.out.println("O resultado da sua conta �: " + resultado);
	sc.close();
}
}
