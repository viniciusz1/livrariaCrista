package vinicius;

import java.util.Scanner;

public class ex5 {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	double n1, n2, mediaBimestral, mediaFinal, provaFinal;
	int casee = 0;
	
	System.out.println("Digite a nota das avalia��es trimestrais: ");
	n1 = sc.nextDouble();
	n2 = sc.nextDouble();
	
	mediaBimestral = (n1+ n2)/2;
	
	if(mediaBimestral>=7) {
		casee = 1;
		mediaFinal = mediaBimestral;
	}else if(mediaBimestral<5) {
		mediaFinal = mediaBimestral;
		casee = 2;
	}else {
		System.out.println("Digite a nota da prova final");
		provaFinal = sc.nextDouble();
		mediaFinal = (mediaBimestral*60 + provaFinal*40)/100;
		System.out.println("Sua m�dia final � de" + mediaFinal);
		
		if(mediaFinal>7) {
			casee = 1;
		}else if(mediaFinal<5) {
			casee = 2;
	}}
	switch(casee) {
	case 1:

		System.out.println("Aluno aprovado");
		break;
	case 2:
		System.out.println("Aluno reprovado");
	}
	
	sc.close();
}
}
