package vinicius;

import java.util.Scanner;

public class ex3 {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	
	int diaNasc, mesNasc, anoNasc, diaAtual, mesAtual, anoAtual, idade, diasTotaisNascimento, diasTotaisAtuais;
	
		System.out.println("Digite a data em que voc� nasceu: ");
	diaNasc = sc.nextInt();
	mesNasc = sc.nextInt();
	anoNasc = sc.nextInt();
	
	System.out.println("Digite a data atual: ");
	diaAtual = sc.nextInt();
	mesAtual = sc.nextInt();
	anoAtual = sc.nextInt();
	
	diasTotaisAtuais = (anoAtual - 1)*365 + (mesAtual - 1)*30 + diaAtual;
	diasTotaisNascimento = (anoNasc - 1)*365 + (mesNasc - 1)*30 + diaNasc;
	
	idade = (diasTotaisAtuais - diasTotaisNascimento)/365;
	
	
	if(idade>=0 && idade<100 && diaNasc <=31 && diaNasc>0 && mesNasc <=12 && mesNasc >0) {
		System.out.println("Sua data de nascimento � v�lida");
	}else {
		System.out.println("Sua data � inv�lida");
	}

	sc.close();
}
}
