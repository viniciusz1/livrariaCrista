package vinicius;

import java.util.Scanner;

public class ex7 {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	
	int prato;
	
	System.out.println("Digite o n�mero do seu prato");
	System.out.println("1- Pizza de camar�o");
	System.out.println("2- Pizza de fil� mignhon");
	System.out.println("3- Pizza de quatro queijo");
	System.out.println("4- Pizza de calabresa");
	System.out.println("5- Pizza de doritos");
	prato = sc.nextInt();
	
	switch(prato){
	case 1:
		System.out.println("\nMassa"
				+ "\nmolho"
				+ "\ncamar�o");
		System.out.println("Deseja confirmar o pedido?\n Digite 1");
		break;
	case 2:
		System.out.println("\nMassa"
				+ "\nFil�"
				+ "\nCamar�o");
		System.out.println("Deseja confirmar o pedido?\n Digite 1");
		break;
	case 3:
		System.out.println("\nMassa"
				+ "\nQueijo"
				+ "\nQueijo"
				+ "\nQueijo"
				+ "\nQueijo");
		System.out.println("Deseja confirmar o pedido?\n Digite 1");
		break;
	case 4:
		System.out.println("\nMassa"
				+ "\nCalabresa"
				+ "\nMolho de tomate");
		System.out.println("Deseja confirmar o pedido?\n Digite 1");
		break;
	case 5:
		System.out.println("\nMassa"
				+ "\nMolho de tomate"
				+ "\ndoritos");
		System.out.println("Deseja confirmar o pedido?\n Digite 1");
		break;
	}

	sc.close();
}
}
