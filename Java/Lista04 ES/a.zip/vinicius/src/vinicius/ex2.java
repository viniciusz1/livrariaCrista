package vinicius;

import java.util.Scanner;

public class ex2 {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int numero, numero3, numero7;
	
	System.out.println("Digite seu n�mero");
	numero = sc.nextInt();
	
	numero3 = numero%3;
	numero7 = numero%7;
	
	numero = numero3 + numero7;
	
	switch(numero) {
	case 0:
		System.out.println("Seu n�mero � divis�vel por 3 e por 7");
		break;
		default:
			System.out.println("Seu n�mero n�o � divis�vel por 3 e por 7");
		
	}
	
sc.close();	
}
}
