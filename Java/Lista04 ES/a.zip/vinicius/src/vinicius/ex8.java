package vinicius;

import java.util.Scanner;

public class ex8 {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	
	
	
	
	
	
	
	
	sc.close();
}
}
